#include <iostream>
#include <fstream>
#include <string>
#include <conio.h>
#include <ctime>
#include <vector>

using namespace std;

void main()
{
	vector <string> pro;
	time_t t1, t2;
	srand(time(0));
	int i, aa, count = 0, firstline = 1, first = 1, stop = 0;;
	string line, a, ID = "", b;
	ifstream myfile;
	fstream forwardindex;
	ifstream prolist;
	prolist.open("list.txt");
	if (prolist.is_open())
	{
		while (getline(prolist, line))
		{
				pro.push_back(line);
		}
	}
	else
	{
		cout << "pro list could be open" << endl;
	}

	t1 = time(0);
	myfile.open("ayat_indexes.txt");
	forwardindex.open("forward_index.txt", ios::out);
	if (forwardindex.is_open())
	{
		if (myfile.is_open())
		{
			while (getline(myfile, line))
			{

				for (i = 0; i < line.length(); i++)
				{
					if (stop == 0)
					{
						if (line[i] == ',')
						{
							stop = 1;
							ID = line.substr(i - count, count);
							count = 0;
							forwardindex << ID << ",";
						}
						else
						{
							count++;
						}
					}
					else
					{
						break;
					}
				}
				for (i; i < line.length(); i++)
				{
					if (line[i] == ' ' || line[i] == ':' || line[i] == ',' || line[i] == '.' || line[i] == ';' || line[i] == '"' || line[i] == '?' || line[i] == '!' || line[i] == '(' || line[i] == ')' || line[i] == '"'|| i == line.length() - 1)
					{
						if (i == line.length() - 1 && line[i] != ' ' && line[i] != ':' && line[i] != ',' && line[i] != '.' && line[i] != ';' && line[i] != '"' && line[i] != '?' && line[i] != '!' && line[i] != '(' && line[i] != ')' && line[i] != '"')
						{
							i++;
							count++;
						}
						a = line.substr(i - count, count);
						b = a;
						if (a.length() <= 2)
						{
							count = 0;
						}
						else
						{
							for (int l = 0; l < b.length(); l++)
							{
								b[l] = tolower(b[l]);
							}
							for (aa = 0; aa < pro.size(); aa++)
							{
								if (pro[aa] == b)
								{
									break;
								}
							}
							if (aa == pro.size())
							{
								forwardindex << a << " ";
							}
							count = 0;
						}
					}
					else
					{
						count++;
					}
				}
				forwardindex << endl;
				stop = 0;
			}
			myfile.close();
			forwardindex.close();
			//}
		}
		else
		{
			cout << "quran_english could not open" << endl;
		}
	}
	else
	{
		cout << "ayat_index could not open" << endl;
	}
	t2 = time(0);
	cout << "time = " << t2 - t1 << endl;
	_getch();
}


