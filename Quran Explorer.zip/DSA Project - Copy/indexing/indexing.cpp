//#include <iostream>
//#include <fstream>
//#include <cstring>
//#include<string>
//#include <conio.h>
//#include <ctime>
//#include <cmath>
//using namespace std;
//
//void main()
//{
//	time_t t1, t2;
//	srand(time(0));
//	int i, id = 0, para = 1, ayat = 0, surah = 0, count = 0, bar = 0,firstline=1;
//	string line, a, ID ="";
//	ifstream myfile;
//	fstream forwardindex;
//	t1 = time(0);
//	myfile.open("quran_english.txt");
//	forwardindex.open("ayat_indexes.txt",ios::out);
//	if (forwardindex.is_open())
//	{
//		if (myfile.is_open())
//		{
//			while (getline(myfile, line))
//			{
//
//				if (firstline == 1)
//				{
//					for (i = 3; i < line.length(); i++)
//					{
//						if (bar < 2)
//						{
//							if (line[i] == '|')
//							{
//								bar++;
//								if (bar == 1)
//								{
//									surah = stoi(line.substr(i - count, count));
//								}
//								if (bar == 2)
//								{
//									ayat = stoi(line.substr(i - count, count));
//								}
//								count = 0;
//							}
//							else
//							{
//								count++;
//							}
//						}
//						else
//						{
//							break;
//						}
//					}
//					id = ayat + (surah * 1000) + (para * 1000000);
//					for (int j = 7; j >= 0; j--)
//					{
//						int temp = id / pow(10,j);
//						temp = temp % 10;
//						ID = ID+(to_string(temp));
//					}
//					a = line.substr(i);
//					forwardindex << ID << "," << a;
//					forwardindex << endl;
//					bar = 0;
//					firstline = 0;
//					ID = "";
//				}
//				else 
//				{
//					if (line == "Paraend")
//					{
//						para++;
//					}
//					else
//					{
//						for (i = 0; i < line.length(); i++)
//						{
//							if (bar < 2)
//							{
//								if (line[i] == '|')
//								{
//									bar++;
//									if (bar == 1)
//									{
//										surah = stoi(line.substr(i - count, count));
//									}
//									if (bar == 2)
//									{
//										ayat = stoi(line.substr(i - count, count));
//									}
//									count = 0;
//								}
//								else
//								{
//									count++;
//								}
//							}
//							else
//							{
//								break;
//							}
//						}
//						id = ayat + (surah * 1000) + (para * 1000000);
//						for (int j = 7; j >= 0; j--)
//						{
//							int temp = id / pow(10, j);
//							temp = temp % 10;
//							ID = ID + (to_string(temp));
//						}
//						a = line.substr(i);
//						forwardindex << ID << "," << a;
//						forwardindex << endl;
//						bar = 0;
//						ID = "";
//					}
//				}
//			}
//			myfile.close();
//			forwardindex.close();
//		}
//		else
//		{
//			cout << "quran_english could not open" << endl;
//		}
//	}
//	else
//	{
//		cout << "ayat_index could not open" << endl;
//	}
//	t2 = time(0);
//	cout << "time = "<<t2 - t1<< endl;
//	_getch();
//}
//
//
